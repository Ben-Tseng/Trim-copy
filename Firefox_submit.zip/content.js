(function () {
  "use strict";

  function getSelectedText() {
    const activeEl = document.activeElement;
    if (
      activeEl &&
      (activeEl.tagName === "TEXTAREA" ||
        (activeEl.tagName === "INPUT" &&
          /^(text|search|url|tel|password|email)$/i.test(activeEl.type)))
    ) {
      const start = activeEl.selectionStart;
      const end = activeEl.selectionEnd;
      if (typeof start === "number" && typeof end === "number" && end > start) {
        return activeEl.value.slice(start, end);
      }
    }

    const selection = window.getSelection();
    if (!selection || selection.isCollapsed) {
      return "";
    }

    return selection.toString();
  }

  function run() {
    const rawText = getSelectedText();
    const trimmedText = rawText.trim();
    if (!trimmedText) {
      return "";
    }
    return trimmedText;
  }

  return run();
})();
