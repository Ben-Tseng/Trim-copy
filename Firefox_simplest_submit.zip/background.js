const api = typeof browser !== "undefined" ? browser : chrome;
"use strict";
const MENU_ID = "trim-copy-selection";

async function getTrimmedTextFromTab(tabId) {
  const code = `(function () {
    function getSelectedText() {
      var activeEl = document.activeElement;
      if (
        activeEl &&
        (activeEl.tagName === "TEXTAREA" ||
          (activeEl.tagName === "INPUT" &&
            /^(text|search|url|tel|password|email)$/i.test(activeEl.type)))
      ) {
        var start = activeEl.selectionStart;
        var end = activeEl.selectionEnd;
        if (typeof start === "number" && typeof end === "number" && end > start) {
          return activeEl.value.slice(start, end);
        }
      }

      var selection = window.getSelection();
      if (!selection || selection.isCollapsed) {
        return "";
      }
      return selection.toString();
    }

    var selected = getSelectedText();
    var trimmed = selected.trim();
    return trimmed || "";
  })();`;

  const results = await api.tabs.executeScript(tabId, { code });
  return Array.isArray(results) ? results[0] : results;
}

async function runTrimCopyForTab(tabId) {
  const trimmedText = await getTrimmedTextFromTab(tabId);
  await copyInBackground(trimmedText);
}

async function copyInBackground(text) {
  if (!text) {
    return false;
  }

  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch (error) {
    // Fall through to execCommand fallback.
  }

  const textarea = document.createElement("textarea");
  textarea.value = text;
  textarea.setAttribute("readonly", "");
  textarea.style.position = "fixed";
  textarea.style.top = "-9999px";
  textarea.style.left = "-9999px";
  document.body.appendChild(textarea);
  textarea.focus();
  textarea.select();

  let copied = false;
  try {
    copied = document.execCommand("copy");
  } finally {
    document.body.removeChild(textarea);
  }
  return copied;
}

function ensureContextMenu() {
  if (!api.contextMenus || !api.contextMenus.create) {
    return;
  }
  try {
    api.contextMenus.remove(MENU_ID, () => {
      api.contextMenus.create({
        id: MENU_ID,
        title: "Trim and Copy",
        contexts: ["selection"]
      });
    });
  } catch (error) {
    api.contextMenus.create({
      id: MENU_ID,
      title: "Trim and Copy",
      contexts: ["selection"]
    });
  }
}

if (api.runtime && api.runtime.onInstalled) {
  api.runtime.onInstalled.addListener(() => ensureContextMenu());
}
if (api.runtime && api.runtime.onStartup) {
  api.runtime.onStartup.addListener(() => ensureContextMenu());
}
ensureContextMenu();

if (api.contextMenus && api.contextMenus.onClicked) {
  api.contextMenus.onClicked.addListener(async (info, tab) => {
    if (!tab || !tab.id || info.menuItemId !== MENU_ID) {
      return;
    }
    const trimmed = String(info.selectionText || "").trim();
    await copyInBackground(trimmed);
  });
}

if (api.commands && api.commands.onCommand) {
  api.commands.onCommand.addListener(async (command) => {
    if (command !== "trim-copy-selection") {
      return;
    }

    try {
      const tabs = await api.tabs.query({ active: true, currentWindow: true });
      const tab = tabs && tabs[0];
      if (!tab || !tab.id) {
        return;
      }
      await runTrimCopyForTab(tab.id);
    } catch (error) {
      console.error("Trim Copy command failed:", error);
    }
  });
}
